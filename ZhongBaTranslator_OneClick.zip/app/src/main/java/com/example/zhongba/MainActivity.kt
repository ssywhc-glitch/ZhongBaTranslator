package com.example.zhongba
import android.content.*
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*

class MainActivity:AppCompatActivity(),TextToSpeech.OnInitListener{
 private lateinit var input:EditText; private lateinit var result:TextView; private lateinit var phonetic:TextView; private lateinit var status:TextView; private lateinit var direction:TextView
 private var pt=true; private var ptText=""; private var tr:Translator?=null; private var tts:TextToSpeech?=null
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  input=findViewById(R.id.input);result=findViewById(R.id.result);phonetic=findViewById(R.id.phonetic);status=findViewById(R.id.status);direction=findViewById(R.id.direction);tts=TextToSpeech(this,this)
  findViewById<Button>(R.id.swap).setOnClickListener{pt=!pt;update()}
  findViewById<Button>(R.id.translate).setOnClickListener{go()}
  findViewById<Button>(R.id.copy).setOnClickListener{(getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("result",result.text));Toast.makeText(this,"已复制",Toast.LENGTH_SHORT).show()}
  findViewById<Button>(R.id.speak).setOnClickListener{if(ptText.isNotBlank())tts?.speak(ptText,TextToSpeech.QUEUE_FLUSH,null,"pt")}
 }
 private fun update(){direction.text=if(pt)"巴西葡萄牙语 → 中文" else "中文 → 巴西葡萄牙语";input.hint=if(pt)"输入巴葡，例如：Quanto custa?" else "输入中文，例如：多少钱？";result.text="—";phonetic.text="—"}
 private fun go(){val s=input.text.toString().trim();if(s.isEmpty())return
  val a=if(pt)TranslateLanguage.PORTUGUESE else TranslateLanguage.CHINESE;val z=if(pt)TranslateLanguage.CHINESE else TranslateLanguage.PORTUGUESE
  tr?.close();tr=Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(a).setTargetLanguage(z).build());status.text="正在准备模型……"
  tr!!.downloadModelIfNeeded(DownloadConditions.Builder().build()).addOnSuccessListener{tr!!.translate(s).addOnSuccessListener{r->result.text=r;if(pt){ptText=s;phonetic.text=ph(s)}else{ptText=r;phonetic.text=ph(r)};status.text="可以离线使用"} .addOnFailureListener{status.text="翻译失败"}}.addOnFailureListener{status.text="首次使用请联网下载模型"}}
 private fun ph(s:String)=mapOf("quanto custa" to "宽托 库斯塔","bom dia" to "邦 吉阿","boa tarde" to "博阿 塔尔吉","boa noite" to "博阿 诺伊特","obrigado" to "奥布里加多","obrigada" to "奥布里加达","por favor" to "波尔 法沃尔","onde fica" to "翁吉 菲卡")[s.lowercase().trim()]?:"辅助谐音："+s
 override fun onInit(c:Int){if(c==TextToSpeech.SUCCESS)tts?.language=java.util.Locale("pt","BR")}
 override fun onDestroy(){tr?.close();tts?.shutdown();super.onDestroy()}
}
